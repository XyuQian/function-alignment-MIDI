import torch
import os
import numpy as np
import argparse
import logging
from torch.utils.tensorboard import SummaryWriter
from torch.utils.data import DataLoader
from shoelace.utils.trainer_utils import Trainer

from tqdm import tqdm
from shoelace.actual_shoelace.midi_data_loader import PairedMIDIDataset
from shoelace.actual_shoelace.midi_data_loader import collate_fn, worker_init_fn
from shoelace.actual_shoelace.midi_shoelace import Shoelace
from midi_config import MODEL_FACTORY, TASKS, MODEL_MAPPING

device = "cuda" if torch.cuda.is_available() else "cpu"


def get_dataset(rid, batch_size, task_type, validation=False):
    num_workers = 0
    dataset = PairedMIDIDataset(
        validation=validation,
        path_folder="data/formatted/ASAP",
        rid=rid,
        task_type=task_type,
        num_workers=num_workers
    )

    # For single-GPU training, we simply use shuffle (for training) instead of a distributed sampler
    dataloader = DataLoader(
        dataset,
        batch_size=batch_size,
        collate_fn=collate_fn,
        shuffle=False,
        num_workers=num_workers,
        worker_init_fn=worker_init_fn,
        pin_memory=True,
        drop_last=True
    )

    return dataset, dataloader


def del_batch(batch):
    if isinstance(batch, dict):
        for k in batch:
            del_batch(batch[k])
    del batch


def move_to_device(batch, dev):
    if isinstance(batch, list):
        return batch
    if isinstance(batch, dict):
        return {k : move_to_device(batch[k], dev) for k in batch}
    return batch.to(dev)


def train(model, dataloader, device, learning_rate, epochs):
    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=1, gamma=0.95)

    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch in tqdm(dataloader, desc=f"Epoch {epoch + 1}/{epochs}"):
            batch = move_to_device(batch, device)
            optimizer.zero_grad()
            loss_dict = model(batch)
            loss = sum([loss_dict[k] for k in loss_dict])
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        avg_loss = total_loss / len(dataloader)
        if epoch % 5 == 0 and epoch > 0:
            print(f"Epoch {epoch}/{epochs}, Loss: {avg_loss:.4f}")
        scheduler.step()
    
    print(f"Epoch {epochs}/{epochs}, Loss: {avg_loss:.4f}")
    print("Training complete.")


if __name__ == "__main__":
    model = Shoelace(
        device=torch.device(device),
        n_prompts=5, # Number of learnable prompts
        model_configs=MODEL_FACTORY,
        task_type="midi_conversion", # Matches the key in TASKS dict
        mask_config={ # Enable potential conditioning in both directions
            "ScoreLM": True,
            "PerformanceLM": True
        }
    ).to(device)

    dataset, dataloader = get_dataset(rid=0, batch_size=4, task_type="midi_conversion")

    train(model, dataloader, device, learning_rate=1e-4, epochs=50)

    # for name, param in model.named_parameters():
    #     if param.requires_grad:
    #         print(f"{name}: {param.size()}, requires_grad={param.requires_grad}")